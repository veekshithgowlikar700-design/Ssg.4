# Sri Sai Ganesh Sewing Machines — Android App

A lightweight Android/Material 3 catalogue app styled like Apple's translucent Liquid Glass aesthetic:
- Large rounded glass cards
- Soft gradients and translucent surfaces
- Product search + category filters
- WhatsApp enquiry and call buttons
- Shop location button
- Current catalogue prices with a transparent ₹500 markup rule
- GitHub Actions one-click APK build

## Shop
**Sri Sai Ganesh Sewing Machines**
Raithu Bazar, Medchal, Secunderabad, Telangana 501401
Beside Canara Bank ATM
Phone / WhatsApp: **9866999286**

## Build APK on GitHub
1. Create a new GitHub repository.
2. Upload all files in this project.
3. Push to the `main` branch.
4. Open **Actions → Build Android APK → Run workflow**.
5. When complete, open the workflow run and download the **SriSaiGanesh-Sewing-debug** artifact.
6. Extract the ZIP and install `app-debug.apk` on Android.

No login, server, database, or API key is required.

## Pricing
Prices were checked online on 8 Oct 2026. The app adds exactly ₹500 to verified reference prices where an exact product price was found. For JACK Z7, the official JACK page does not publish an India selling price, so the app deliberately shows **Price on request** rather than inventing a price.

Reference prices:
- Vidya Bernette Sew&Go 1: ₹12,399 reference → ₹12,899 shop price
- Vidya 95T10: ₹9,000 reference → ₹9,500 shop price
- JACK K7 AI Interlock: ₹1,24,500 reference → ₹1,25,000 shop price
- JACK F6 Lockstitch: ₹24,000 reference → ₹24,500 shop price
- JACK Z7: India online price not publicly listed on the official page → Price on request

See `PRICE_SOURCES.md` for source pages.
