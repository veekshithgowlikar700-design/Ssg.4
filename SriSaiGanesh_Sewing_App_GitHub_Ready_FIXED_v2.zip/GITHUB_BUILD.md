# One-click APK build

This project is prepared for GitHub Actions.

1. Upload/extract the **contents of this ZIP into the root of your GitHub repository**.
2. Commit to the `main` branch.
3. Open **Actions → Build Android APK → Run workflow**.
4. When it finishes, open the workflow run and download the artifact **SriSaiGanesh-Sewing-debug**.

The workflow uses JDK 17 and Gradle 8.9 installed by GitHub Actions. It does **not** require `gradlew`, so the previous `chmod: cannot access 'gradlew'` error is avoided.

The APK is an unsigned debug APK for testing/direct installation.
